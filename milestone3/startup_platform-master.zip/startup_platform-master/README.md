# startup_platform
